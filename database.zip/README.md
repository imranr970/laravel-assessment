

## About Laravel Assessment

This is Laravel Assessment API for inviting users and creating their account.



## Workflow

- ** Admin will invite a user with some invite token, only by providing that token user can create username and password.- **
- ** 6 digit pin code will be sent to user which he can use to verify his account.**
- ** User can login and update his/her profile.**


### Third Party Packages

- **Tymon/jwt-auth**
