<?php return array (
  'App\\Providers\\EventServiceProvider' => 
  array (
    'App\\Events\\send_invite_email_to_user' => 
    array (
      0 => 'App\\Listeners\\listen_send_email_to_user',
    ),
    'App\\Events\\send_pin_to_users' => 
    array (
      0 => 'App\\Listeners\\listen_to_send_pin_to_users',
    ),
  ),
);